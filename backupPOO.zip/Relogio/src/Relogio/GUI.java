package Relogio;

import java.awt.*;
import javax.swing.*;

public class GUI {
	
	JFrame frame;
	JTextField horaCampo;
	JTextField minutoCampo;
	JTextField segundoCampo;

	public GUI() {
		super();
		frame = new JFrame("Rel�gio");
		horaCampo = new JTextField(2);
		horaCampo.setText("00");
		minutoCampo = new JTextField(2);
		minutoCampo.setText("00");
		segundoCampo = new JTextField(2);
		segundoCampo.setText("00");
		// TODO Auto-generated constructor stub
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	
	public JTextField getHoraCampo() {
		return horaCampo;
	}

	public void setHoraCampo(JTextField horaCampo) {
		this.horaCampo = horaCampo;
	}

	public JTextField getMinutoCampo() {
		return minutoCampo;
	}

	public void setMinutoCampo(JTextField minutoCampo) {
		this.minutoCampo = minutoCampo;
	}

	public JTextField getSegundoCampo() {
		return segundoCampo;
	}

	public void setSegundoCampo(JTextField segundoCampo) {
		this.segundoCampo = segundoCampo;
	}

	public void constroiJanela(){ 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(200, 100);
		frame.setResizable(false);
		frame.getContentPane().setLayout(new FlowLayout());
		frame.getContentPane().add(horaCampo);
		frame.getContentPane().add(minutoCampo);
		frame.getContentPane().add(segundoCampo);
		frame.setVisible(true);	
	}
	
	public void constroiJanelaInicial(){ 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(200, 100);
		frame.setResizable(false);
		frame.getContentPane().setLayout(new FlowLayout());
		frame.getContentPane().add(horaCampo);
		frame.getContentPane().add(minutoCampo);
		frame.getContentPane().add(segundoCampo);
		frame.setVisible(true);	
	}


}
