package Relogio;

public class Relogio {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Maquina maq = new Maquina(0,0,0);
	}

}
