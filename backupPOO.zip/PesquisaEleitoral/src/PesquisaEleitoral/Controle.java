package PesquisaEleitoral;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Controle implements ActionListener{
	
	Listas cidades;
	
	
	Questionario questAtual; 
	Cidade cidadeAtual;
	
	JFrame frame;
	JButton botao = new JButton("Inicio");
	JButton botaoFinal = new JButton("Avaliar");
	JLabel rotulo1 = new JLabel("Come�ar questin�rio: ");
	JLabel rotuloCidade = new JLabel("Nome da cidade: ");
	JTextField textoCidade = new JTextField(15);
	
	JFrame frameQuest;
	JLabel rotuloCandidato = new JLabel("Nome dao candidato: ");
	JTextField textoCandidato = new JTextField(15);
	JComboBox comboSex = new JComboBox();
	JComboBox comboEsq = new JComboBox();
	JComboBox comboEt = new JComboBox();
	JComboBox comboRend = new JComboBox();
	JButton botaoProxQuest = new JButton("Prox");
	JButton botaoFimCidade = new JButton("FimCidade");

	public Controle() {
		super();
		cidades = new Listas();
		// TODO Auto-generated constructor stub
	}

	public Listas getCidades() {
		return cidades;
	}

	public void setCidades(Listas cidades) {
		this.cidades = cidades;
	}
	
	public void inicioGeral(){
		frame = new JFrame("Pesquisa");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 200);
		frame.setLocation(200, 200);
		frame.setResizable(false);
		frame.getContentPane().setLayout(new FlowLayout());
		
		botao.addActionListener(this);
		
		frame.getContentPane().add(rotuloCidade);
		frame.getContentPane().add(textoCidade);
		frame.getContentPane().add(botao);
		frame.getContentPane().add(botaoFinal);
		
		frame.setVisible(true);	
		
		frameQuest = new JFrame("Question�rio");
		frameQuest.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameQuest.setSize(400, 300);
		frameQuest.setLocation(200, 200);
		frameQuest.setResizable(false);
		frameQuest.getContentPane().setLayout(new GridLayout(10,1));
		comboSex.addItem("Masculino");
		comboSex.addItem("Feminino");
		comboEsq.addItem("n�o escolarizado");
		comboEsq.addItem("primeiro grau completo");
		comboEsq.addItem("segundo grau completo");
		comboEsq.addItem("terceiro grau completo");
		comboEt.addItem("<20");
		comboEt.addItem(">20 <30");
		comboEt.addItem(">30 <40");
		comboEt.addItem(">40 <50");
		comboEt.addItem(">50");
		comboRend.addItem("<3");
		comboRend.addItem(">3 <5");
		comboRend.addItem(">5");
		
		
		frameQuest.getContentPane().add(rotuloCandidato);
		frameQuest.getContentPane().add(textoCandidato);
		frameQuest.getContentPane().add(comboSex);
		frameQuest.getContentPane().add(comboEsq);
		frameQuest.getContentPane().add(comboEt);
		frameQuest.getContentPane().add(comboRend);
		
		frameQuest.getContentPane().add(botaoProxQuest);
		botaoProxQuest.addActionListener(this);
		frameQuest.getContentPane().add(botaoFimCidade);
		botaoFimCidade.addActionListener(this);
	}
	
	public Questionario preencheQuestionario(){
		
		
		Questionario questionario = new Questionario();
		
		questionario.setCandidato(textoCandidato.getText());
		questionario.setSexo(comboSex.getSelectedIndex());
		questionario.setEscolaridade(comboEsq.getSelectedIndex());
		questionario.setFaixaEt(comboEt.getSelectedIndex());
		questionario.setFaixaSal(comboRend.getSelectedIndex());
		
		
		//JOptionPane.showMessageDialog(null, questionario.getCandidato());
		return questionario;
	}
	
	public void preenchecandidatos(){
		for(int i =0; i<cidades.size();i++){
			Cidade cidadeAnalizada = ((Cidade) cidades.get(i));
			for(int j =0; i < cidadeAnalizada.getQuests().size(); j++){
				Questionario questAnalizado = ((Questionario)((Cidade) cidades.get(i)).getQuests().get(j));
				
				String nomeCandidato = questAnalizado.getCandidato();
				boolean igual = false;
				for(int k = 0; k < cidadeAnalizada.getCandidatos().size(); k++){
					Candidatos candidatoConferido = (Candidatos)cidadeAnalizada.getCandidatos().get(k);
					if(candidatoConferido.getNome().equals(nomeCandidato)){
						igual = true;
						candidatoConferido.atualiza(questAnalizado);
					}
				}
				
				if(igual==false){
					Candidatos novoCandidato = new Candidatos();
					novoCandidato.setNome(nomeCandidato);
					novoCandidato.atualiza(questAnalizado);
				}
			}
		}
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == botao){
			JOptionPane.showMessageDialog(null, "come�ando "+" "+textoCidade.getText());
			//inicioCidade(textoCidade.getText());
			Cidade cidade = new Cidade();
			cidade.setNome(textoCidade.getText());
			cidadeAtual = cidade;
			textoCidade.setText(null);
			frame.setVisible(false);	
			frameQuest.setVisible(true);
			
			}
		if (e.getSource() == botaoProxQuest){
			questAtual = preencheQuestionario();
			cidadeAtual.quests.add(questAtual);
			JOptionPane.showMessageDialog(null, "dando voto para "+" "+questAtual.getCandidato()+ " " + comboSex.getSelectedIndex());
			textoCandidato.setText(null);
			comboSex.setSelectedIndex(0);
			comboEsq.setSelectedIndex(0);
			comboEt.setSelectedIndex(0);
			comboRend.setSelectedIndex(0);
			
		}
		if (e.getSource() == botaoFimCidade){
			cidades.add(cidadeAtual);
			frameQuest.setVisible(false);
			frame.setVisible(true);
			
		}
		if (e.getSource() == botaoFinal){
			frameQuest.setVisible(false);
			frame.setVisible(false);
			
		}
		
	}

}
