package PesquisaEleitoral;

public class Candidatos {
	
	String nome;
	int eleitores;//numero de eleitores;
	int eleitoras;//numero de eleitoras;
	int[] faixasEtaria;
	int[] faixasSalarial;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getEleitores() {
		return eleitores;
	}
	public void setEleitores(int eleitores) {
		this.eleitores = eleitores;
	}
	public int getEleitoras() {
		return eleitoras;
	}
	public void setEleitoras(int eleitoras) {
		this.eleitoras = eleitoras;
	}
	public int[] getFaixasEtaria() {
		return faixasEtaria;
	}
	public void setFaixasEtaria(int[] faixasEtaria) {
		this.faixasEtaria = faixasEtaria;
	}
	public int[] getFaixasSalarial() {
		return faixasSalarial;
	}
	public void setFaixasSalarial(int[] faixasSalarial) {
		this.faixasSalarial = faixasSalarial;
	}
	
	public void atualiza(Questionario questionario){
		
	}

}
