/*
 * 
 * 
 * 
 */
package PesquisaEleitoral;

public class PesquisaEleitoral {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Controle controle = new Controle();
		controle.inicioGeral();

	}

}
